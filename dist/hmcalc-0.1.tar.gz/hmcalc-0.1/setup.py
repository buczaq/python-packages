from setuptools import setup, find_packages

setup(
    name='hmcalc',
    version='0.1',
    packages=find_packages(exclude=['tests*']),
    license='MIT',
    description='calculation packages',
    url='https://github.com/buczaq/python-packages',
    author='Krzysztof Buczak',
    author_email='226153@student.pwr.edu.pl'
)
